package phase1.FinalProject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

public class MovieTicket {
	private static String adminusername = "Admin";
	private static String adminpass = "12345";
	public static String moviename= "RRR";
	public static int fare = 250;
	private static int count;
	private static String time;
	
	public static void movieinfo() {
		System.out.println("\nMovie on the Screen: " + moviename);
		System.out.println("Fare: Rs "+fare);
	}

	public static void main(String[] args) {
		
		System.out.println("**************************************************");
		System.out.println("\tWelcome to the Movie Ticket Booking");
		System.out.println("**************************************************");

		ArrayList<String> B = new ArrayList<String>();
		ArrayList<Integer> seats = new ArrayList<Integer>();
		optionselection(B,seats);
		
	}
	public static void optionselection(ArrayList<String> B,ArrayList<Integer> seats) {
		
		while(true) {
			
			System.out.println("\n1 -> Are you Admin \n2 -> Are you User \n3 -> Exit");
			Scanner sc =  new Scanner(System.in);
			int choice = sc.nextInt();
			if(choice == 3) {
				System.out.println("Thanks for using Application");
				break;
			}
			
			switch(choice) {
			   
			case 1:
				System.out.println("Hello! "+ adminusername);
				System.out.println("Do you want to update password type 'y' or if no type 'n'");
				
				char c = sc.next().charAt(0);
				
				
				switch(c) {
				
				case 'y':
					
					System.out.println("Enter the new password:");
					String pass = sc.next();
					setAdminpass(pass);
					System.out.println("Password updated successfully");
					
					break;
					
				case 'n':
					 
					break;
					
				default: 
					System.out.println("Wrong choice! type 'y' for yes or 'n' for no");
					break;
				}
				break;
				
			case 2: 
				for(int i=0; i<10; i++) {
					B.add("Not Booked");
				}
				movieinfo();
				time=setShowtime(B,seats);
				selectseat(B,seats);
				reselect(B,seats);
				
			}
		}
	}

	
	private static String setShowtime(ArrayList<String> B,ArrayList<Integer> seats) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nSelect Show time: ");
		System.out.println("1) 9 AM - 12 PM \n2) 1 PM - 4 PM \n3) 6 AM - 9 PM");
		int chs = sc.nextInt();
		if(chs == 1) {
			
			return "9 AM - 12 PM";
			
		}else if(chs == 2) {
			
			return "1 PM - 4 PM";
			
		}else if(chs == 3) {
			
			return "6 AM - 9 PM";
			
		}else {
			
			System.out.println("Invalid");
			return setShowtime(B,seats);
		}
		
	}

	private static void selectseat(ArrayList<String> B,ArrayList<Integer> seats) {
		count = 0;
		System.out.println("Select the seat(1 - 10)");
		Scanner sc = new Scanner(System.in);
		int seat = sc.nextInt();
	   
		if(B.get(seat-1).equalsIgnoreCase("Not Booked")) {
			seats.add(seat);
		}
        
	
		if(B.get(seat-1).equalsIgnoreCase("Not Booked")){
			B.set(seat-1, "Booked");
			System.out.println("You have Successfully Booked the seat");
			for(int i=0; i<10;i++) {
				if(B.get(i) == "Booked") {
					
					count++;
				}
			}
			System.out.println("You have booked: "+count + " seat");
			
		}else {
			System.out.println("\nSeat you have choosed is already Booked");
		}
		System.out.println();
		System.out.println("Seats: "+B);
		
	}

	private static void reselect(ArrayList<String> B,ArrayList<Integer> seats) {
		
		while(true) {
			
			Scanner sc = new Scanner(System.in);
			System.out.println("\nDo you want to book another seat type (y/n):");
			char ch = sc.next().charAt(0);
			
			if(ch!='y' && ch=='n') {
				titcketinfo(seats);
				B.clear();
				seats.clear();
				break;
			}else {
				
				switch(ch) {
				
				case 'y':
					
					selectseat(B,seats);
					break;
				
				case 'n':
					titcketinfo(seats);
					B.clear();
					seats.clear();
					break;
			  }
				
			}
		}
		
	}
	
	private static void titcketinfo(ArrayList<Integer> seats) {
		
		System.out.println("\n************************************************************");
		System.out.println("\tTicket information: ");
		System.out.println("\n\t\tBooking Time: "+Calendar.getInstance().getTime());
		System.out.println("\nMovie : " + moviename);
		System.out.println("Show Timing: "+time);
		System.out.println("Seat No: " + seats);
		System.out.println("Total Amount: Rs "+ (fare*count));
		System.out.println("************************************************************");
		
	}
	public static String getAdminpass() {
		return adminpass;
	}
	public static void setAdminpass(String adminpass) {
		MovieTicket.adminpass = adminpass;
	}
}



